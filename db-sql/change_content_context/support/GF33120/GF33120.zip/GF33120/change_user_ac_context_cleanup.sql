/*L
  Copyright ScenPro Inc, SAIC-F

  Distributed under the OSI-approved BSD 3-Clause License.
  See http://ncip.github.com/cadsr-cdecurate/LICENSE.txt for details.
L*/

--Please run with account SBR
DROP TABLE SBR.AC_BACKUP1;

DROP TABLE SBR.DEC_BACKUP1;

DROP TABLE SBR.DE_BACKUP1;

DROP TABLE SBR.VD_BACKUP1;

exit
