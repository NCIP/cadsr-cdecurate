/*L
  Copyright ScenPro Inc, SAIC-F

  Distributed under the OSI-approved BSD 3-Clause License.
  See http://ncip.github.com/cadsr-cdecurate/LICENSE.txt for details.
L*/

SQL*Plus: Release 10.2.0.4.0 - Production on Fri Jun 28 09:39:08 2013

Copyright (c) 1982, 2007, Oracle.  All Rights Reserved.


Connected to:
Oracle Database 10g Enterprise Edition Release 10.2.0.5.0 - 64bit Production
With the Partitioning, Data Mining and Real Application Testing options

SQL> @change_user_ac_context-smitha.sql

13 rows updated.


15 rows updated.


5 rows updated.


0 rows updated.

SQL> @change_user_ac_context-scottm.sql

14 rows updated.


26 rows updated.


6 rows updated.


0 rows updated.

SQL> @change_user_ac_context-kearnsd.sql

58 rows updated.


80 rows updated.


40 rows updated.


0 rows updated.

SQL> 