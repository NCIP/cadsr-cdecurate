This folder contains sql scripts which are used to update 
load_tool_options for EVS and url.
Whenever EVS is updated, we run these scripts to update the tool.