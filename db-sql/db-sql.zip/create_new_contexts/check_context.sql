/*L
  Copyright ScenPro Inc, SAIC-F

  Distributed under the OSI-approved BSD 3-Clause License.
  See http://ncip.github.com/cadsr-cdecurate/LICENSE.txt for details.
L*/

select DATE_CREATED, SCL_NAME, DESCRIPTION from security_contexts_lov_view order by DATE_CREATED desc
/
