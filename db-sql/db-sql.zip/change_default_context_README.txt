*** APPLYING CHANGES ***

Run with user SBREXT:

SQL> @change_default_context_to_NCIP.sql

1 row updated.


Commit complete.


NAME
------------------------------
NCIP


NAME
------------------------------
NCIP

SQL>