/*L
  Copyright ScenPro Inc, SAIC-F

  Distributed under the OSI-approved BSD 3-Clause License.
  See http://ncip.github.com/cadsr-cdecurate/LICENSE.txt for details.
L*/

INSERT INTO sbrext.definition_types_lov_view_ext (defl_name)
  VALUES   ('Synonym');

COMMIT;